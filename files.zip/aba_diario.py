"""
aba_diario.py — Aba 2: Diário de Classe (Inserção Rápida).

PASSO 3 — O desafio do st.data_editor com o banco de dados.

Estratégia adotada (Pivot Table Pattern):
  1. Buscamos os dados do banco em formato "longo" (um registro por célula).
  2. Transformamos para formato "largo" (pivot): cada competência vira uma coluna.
  3. O professor edita o DataFrame no st.data_editor (visual de planilha).
  4. Ao salvar, fazemos o "unpivot" de volta para o formato longo e persistimos
     em lote com ON CONFLICT ... DO UPDATE (UPSERT).

Isso garante que:
  - O grid seja sempre fiel ao estado do banco.
  - Valores nulos (aluno sem nota) sejam exibidos como células vazias.
  - O salvamento seja atômico (tudo ou nada).
"""

import streamlit as st
import pandas as pd
from datetime import date
from repositorios import (
    listar_alunos,
    listar_competencias,
    buscar_grid_diario,
    salvar_avaliacoes_em_lote,
    buscar_presenca_por_data,
    salvar_presenca_em_lote,
)


def renderizar() -> None:
    """Renderiza a aba do Diário de Classe."""

    st.markdown("## 📖 Diário de Classe")
    st.caption(
        "Edite as notas e presenças diretamente nas células. "
        "Clique em **Salvar** ao finalizar."
    )

    # Verificação inicial: precisa ter alunos e competências cadastradas
    alunos       = listar_alunos()
    competencias = listar_competencias()

    if not alunos:
        st.warning("⚠️ Nenhum aluno cadastrado. Vá para a aba **Cadastros** primeiro.")
        return

    if not competencias:
        st.warning("⚠️ Nenhuma competência cadastrada. Vá para a aba **Cadastros** primeiro.")
        return

    # ─── Seleção de Data ──────────────────────────────────────────────────────
    st.markdown("### 📅 Data da Aula / Avaliação")

    col_data, col_turma, _ = st.columns([2, 2, 3])
    with col_data:
        data_selecionada: date = st.date_input(
            "Data",
            value=date.today(),
            format="DD/MM/YYYY",
            label_visibility="collapsed",
        )
    with col_turma:
        turmas_disponiveis = sorted(set(a["turma"] for a in alunos))
        turma_filtro = st.selectbox(
            "Filtrar por turma",
            options=["Todas"] + turmas_disponiveis,
            label_visibility="collapsed",
        )

    data_str = data_selecionada.strftime("%Y-%m-%d")

    # Aplica filtro de turma
    alunos_filtrados = (
        alunos if turma_filtro == "Todas"
        else [a for a in alunos if a["turma"] == turma_filtro]
    )

    st.divider()

    # ─── Seção de Notas ───────────────────────────────────────────────────────
    st.markdown("### 📝 Notas por Competência (0–10)")

    df_notas = _construir_dataframe_notas(alunos_filtrados, competencias, data_str)
    df_notas_editado = _renderizar_editor_notas(df_notas, competencias)

    st.divider()

    # ─── Seção de Presença ────────────────────────────────────────────────────
    st.markdown("### ✅ Registro de Presença")

    df_presenca = _construir_dataframe_presenca(alunos_filtrados, data_str)
    df_presenca_editado = _renderizar_editor_presenca(df_presenca)

    st.divider()

    # ─── Botão de Salvar ──────────────────────────────────────────────────────
    col_btn, col_info = st.columns([2, 5])
    with col_btn:
        salvar = st.button(
            "💾 Salvar Tudo",
            type="primary",
            use_container_width=True,
        )

    if salvar:
        with st.spinner("Salvando no banco de dados..."):
            try:
                _persistir_notas(df_notas_editado, competencias, data_str)
                _persistir_presenca(df_presenca_editado, data_str)
                st.success(
                    f"✅ Dados de **{data_selecionada.strftime('%d/%m/%Y')}** "
                    f"salvos com sucesso para **{len(alunos_filtrados)}** aluno(s)!"
                )
            except Exception as e:
                st.error(f"❌ Erro ao salvar: {e}")


# ─── Helpers: Construção dos DataFrames ───────────────────────────────────────

def _construir_dataframe_notas(
    alunos: list[dict],
    competencias: list[dict],
    data_str: str,
) -> pd.DataFrame:
    """
    Constrói o DataFrame no formato "largo" (pivot):
      Colunas: aluno_id | Aluno | Turma | [competência_1] | [competência_2] | ...

    Valores nulos representam alunos ainda não avaliados naquela competência.
    """
    # Busca dados existentes no banco para a data
    registros_banco = buscar_grid_diario(data_str)

    # Filtra pelos alunos visíveis na tela
    ids_visiveis = {a["id"] for a in alunos}
    registros_banco = [r for r in registros_banco if r["aluno_id"] in ids_visiveis]

    if registros_banco:
        df_longo = pd.DataFrame(registros_banco)
        # Pivot: cada competência → coluna separada
        df_pivot = df_longo.pivot_table(
            index=["aluno_id", "aluno_nome", "turma"],
            columns="nome_competencia",
            values="nota",
            aggfunc="first",  # pega o primeiro valor (data já filtrada)
        ).reset_index()
        df_pivot.columns.name = None  # Remove o nome do índice de colunas
    else:
        # Nenhum dado no banco: cria DataFrame vazio com a estrutura correta
        df_pivot = pd.DataFrame(
            {
                "aluno_id":   [a["id"]   for a in alunos],
                "aluno_nome": [a["nome"] for a in alunos],
                "turma":      [a["turma"] for a in alunos],
            }
        )
        for comp in competencias:
            df_pivot[comp["nome_competencia"]] = None

    # Garante que todas as colunas de competências existam (mesmo sem dados)
    for comp in competencias:
        if comp["nome_competencia"] not in df_pivot.columns:
            df_pivot[comp["nome_competencia"]] = None

    return df_pivot


def _construir_dataframe_presenca(
    alunos: list[dict],
    data_str: str,
) -> pd.DataFrame:
    """
    Constrói o DataFrame de presença.
    Padrão: todos presentes (True) caso ainda não haja registro.
    """
    registros = buscar_presenca_por_data(data_str)
    ids_visiveis = {a["id"] for a in alunos}
    registros = [r for r in registros if r["aluno_id"] in ids_visiveis]

    if registros:
        df = pd.DataFrame(registros)
        df["Presente"] = df["status_presente"].astype(bool)
    else:
        df = pd.DataFrame(
            {
                "aluno_id":   [a["id"]   for a in alunos],
                "aluno_nome": [a["nome"] for a in alunos],
                "turma":      [a["turma"] for a in alunos],
            }
        )
        df["Presente"] = True

    return df[["aluno_id", "aluno_nome", "turma", "Presente"]]


# ─── Helpers: Renderização do st.data_editor ──────────────────────────────────

def _renderizar_editor_notas(
    df: pd.DataFrame,
    competencias: list[dict],
) -> pd.DataFrame:
    """
    Renderiza o data_editor de notas com configuração de colunas precisa:
      - Colunas de ID/nome: somente leitura (disabled).
      - Colunas de competência: editáveis, tipo float, range 0–10.
    """
    nomes_competencias = [c["nome_competencia"] for c in competencias]

    # Configura quais colunas são editáveis e seus tipos
    config_colunas = {
        "aluno_id": st.column_config.NumberColumn("ID", disabled=True, width="small"),
        "aluno_nome": st.column_config.TextColumn("Aluno", disabled=True, width="medium"),
        "turma": st.column_config.TextColumn("Turma", disabled=True, width="small"),
    }

    for nome_comp in nomes_competencias:
        config_colunas[nome_comp] = st.column_config.NumberColumn(
            nome_comp,
            min_value=0.0,
            max_value=10.0,
            step=0.5,
            format="%.1f",
            help=f"Nota de 0 a 10 para: {nome_comp}",
        )

    df_editado = st.data_editor(
        df,
        column_config=config_colunas,
        use_container_width=True,
        hide_index=True,
        num_rows="fixed",       # Não permite adicionar/remover linhas
        key="editor_notas",
    )

    return df_editado


def _renderizar_editor_presenca(df: pd.DataFrame) -> pd.DataFrame:
    """
    Renderiza o data_editor de presença com checkbox na coluna 'Presente'.
    """
    config_colunas = {
        "aluno_id":   st.column_config.NumberColumn("ID",    disabled=True, width="small"),
        "aluno_nome": st.column_config.TextColumn("Aluno",   disabled=True, width="medium"),
        "turma":      st.column_config.TextColumn("Turma",   disabled=True, width="small"),
        "Presente":   st.column_config.CheckboxColumn(
            "Presente",
            help="Marque para indicar presença",
            default=True,
        ),
    }

    df_editado = st.data_editor(
        df,
        column_config=config_colunas,
        use_container_width=True,
        hide_index=True,
        num_rows="fixed",
        key="editor_presenca",
    )

    return df_editado


# ─── Helpers: Persistência (Unpivot + UPSERT) ─────────────────────────────────

def _persistir_notas(
    df: pd.DataFrame,
    competencias: list[dict],
    data_str: str,
) -> None:
    """
    Faz o "unpivot" do DataFrame editado e salva em lote no banco.

    Para cada célula (aluno × competência):
      - Se o valor for NaN/None → salva como NULL (aluno não avaliado).
      - Caso contrário, persiste a nota.
    """
    registros = []
    nomes_competencias = {c["nome_competencia"]: c["id"] for c in competencias}

    for _, linha in df.iterrows():
        aluno_id = int(linha["aluno_id"])
        for nome_comp, comp_id in nomes_competencias.items():
            valor = linha.get(nome_comp)
            # Trata NaN do pandas como None (NULL no banco)
            nota = None if pd.isna(valor) else float(valor)
            registros.append({
                "aluno_id":      aluno_id,
                "competencia_id": comp_id,
                "nota":          nota,
            })

    salvar_avaliacoes_em_lote(registros, data_str)


def _persistir_presenca(df: pd.DataFrame, data_str: str) -> None:
    """Converte o DataFrame de presença para lista de dicts e persiste."""
    registros = [
        {
            "aluno_id": int(row["aluno_id"]),
            "presente": bool(row["Presente"]),
        }
        for _, row in df.iterrows()
    ]
    salvar_presenca_em_lote(registros, data_str)
